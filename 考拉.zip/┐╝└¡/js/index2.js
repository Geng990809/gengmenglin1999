function exchange(){
    let click = document.querySelectorAll('.exchange');
    let btn = document.querySelectorAll('.titleRight a');
    btn.onclick = function(){
        
    }
}